package music.string;
import music.Playable;
public class Veena implements Playable {
    @Override
    public void play() {
        System.out.println("Playing the Veena: Rich, classical string vibrations sound.");
    }
}
